const express = require('express');
const http = require('http');
 
const app = express();
const server = http.createServer(app);
const io = require('socket.io')(server);
 
let waiting = null;
 
io.on('connection', (sock) => {
  sock.emit('msg', 'You are connected');
  sock.on('msg', (msg) => io.emit('msg', msg));
 
  if (waiting === null) {
    sock.emit('msg', 'You Are Waiting');
    waiting = sock;
  } else {
    startGame(waiting, sock);
    waiting = null;
  }
 
});
 
let roomId = 1;
 
function startGame(p1, p2) {
  const roomName = 'RPS' + roomId++;
 
  let p1Turn = null;
  let p2Turn = null;
 
  [p1, p2].forEach((p) => p.join(roomName));
  io.to(roomName).emit('msg', 'Game Started!');
 
  p1.on('turn', (e) => {
    console.log(e);
    p1Turn = e;
    checkRoundEnd();
  });
 
  p2.on('turn', (e) => {
    console.log(e);
    p2Turn = e;
    checkRoundEnd();
  });
 
  function checkRoundEnd() {
    if (p1Turn !== null && p2Turn !== null) {
      io.to(roomName).emit('msg', 'Round Ended! P1 - '
        + p1Turn + ' P2 - ' + p2Turn);
 
      io.to(roomName).emit('msg', 'Next round!');
 
      p1Turn = p2Turn = null;
    }
  }
}
 
app.use(express.static(`${__dirname}/public`));
 
server.listen(3000, () => console.log('Ready on 0.0.0.0:3000'));